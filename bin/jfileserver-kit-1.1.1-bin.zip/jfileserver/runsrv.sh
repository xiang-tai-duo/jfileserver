#!/usr/bin/env bash

echo "JFileServer starting, enter 'x' to shutdown server, 'r' to restart server ..."
java -cp .:lib/* org.filesys.app.FileServer fileSrvConfig.xml
